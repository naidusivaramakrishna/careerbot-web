"use client";

import Footer from "@/app/Footer/page";
import Header from "@/components/layout/Header";
import Sidebar from "@/components/layout/Sidebar";

export default function ClientLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <>
      <Sidebar />
      <Header />
      <div
        className="pt-14 min-h-screen bg-gray-50 transition-[margin] duration-300"
        style={{ marginLeft: "var(--sidebar-width, 56px)" }}
      >
        {children}
        <Footer />
      </div>
    </>
  );
}

'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import {
  Search, ChevronLeft, Mail, Phone
} from 'lucide-react';
import jobsApi from '@/api/jobsApi';
import logger from '@/lib/logger';
import DashboardLayout from '../dashboard/_components/DashboardLayout';
import ScheduleInterviewModal from './_components/ScheduleInterviewModal';

// SVG Icons
const ViewIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-4 h-4">
    <path d="M1.37856 8.23675C1.32303 8.08716 1.32303 7.92262 1.37856 7.77304C1.91935 6.46176 2.83732 5.34058 4.01609 4.55165C5.19486 3.76272 6.58133 3.34155 7.99975 3.34155C9.41817 3.34155 10.8046 3.76272 11.9834 4.55165C13.1622 5.34058 14.0801 6.46176 14.6209 7.77304C14.6765 7.92262 14.6765 8.08716 14.6209 8.23675C14.0801 9.54802 13.1622 10.6692 11.9834 11.4581C10.8046 12.2471 9.41817 12.6682 7.99975 12.6682C6.58133 12.6682 5.19486 12.2471 4.01609 11.4581C2.83732 10.6692 1.91935 9.54802 1.37856 8.23675Z" stroke="currentColor" strokeWidth="1.3325" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M8.00018 10.0047C9.1043 10.0047 9.99938 9.10968 9.99938 8.00555C9.99938 6.90142 9.1043 6.00635 8.00018 6.00635C6.89605 6.00635 6.00098 6.90142 6.00098 8.00555C6.00098 9.10968 6.89605 10.0047 8.00018 10.0047Z" stroke="currentColor" strokeWidth="1.3325" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const ShortlistIcon = () => (
  <svg width="17" height="21" viewBox="0 0 17 21" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-4 h-4">
    <path d="M12 4C12 6.20914 10.2091 8 8 8C5.79086 8 4 6.20914 4 4C4 1.79086 5.79086 0 8 0C10.2091 0 12 1.79086 12 4Z" fill="currentColor"/>
    <path d="M10.2951 11.1879C8.2137 12.0529 6.75 14.1055 6.75 16.5C6.75 17.8163 7.1943 19.0315 7.9378 20C4.76837e-07 19.9895 0 17.9788 0 15.5C0 13.0147 3.58172 11 8 11C8.7977 11 9.5681 11.0657 10.2951 11.1879Z" fill="currentColor"/>
    <path d="M12.25 20.5C13.0906 20.5 13.9123 20.2507 14.6112 19.7837C15.3101 19.3167 15.8548 18.653 16.1765 17.8764C16.4982 17.0998 16.5823 16.2453 16.4183 15.4209C16.2543 14.5964 15.8496 13.8392 15.2552 13.2448C14.6608 12.6504 13.9036 12.2457 13.0791 12.0817C12.2547 11.9177 11.4002 12.0018 10.6236 12.3235C9.84701 12.6452 9.18325 13.1899 8.71625 13.8888C8.24926 14.5877 8 15.4094 8 16.25C8.00173 17.3766 8.45005 18.4566 9.24671 19.2533C10.0434 20.0499 11.1234 20.4983 12.25 20.5ZM14.5385 14.4715C14.6072 14.5231 14.665 14.5876 14.7088 14.6615C14.7525 14.7354 14.7813 14.8171 14.7934 14.9021C14.8056 14.9871 14.8009 15.0737 14.7795 15.1569C14.7582 15.2401 14.7207 15.3182 14.6692 15.3869L12.6096 18.1331C12.5063 18.2687 12.3753 18.3808 12.2254 18.4619C12.0755 18.5431 11.91 18.5915 11.74 18.6038H11.6615C11.3479 18.6025 11.0474 18.478 10.8246 18.2573L9.76538 17.1915C9.69694 17.1329 9.64135 17.0608 9.6021 16.9797C9.56286 16.8986 9.5408 16.8102 9.53732 16.7202C9.53385 16.6301 9.54902 16.5403 9.58189 16.4564C9.61476 16.3725 9.66462 16.2963 9.72834 16.2326C9.79206 16.1689 9.86827 16.119 9.95217 16.0861C10.0361 16.0533 10.1259 16.0381 10.2159 16.0416C10.306 16.045 10.3943 16.0671 10.4754 16.1063C10.5566 16.1456 10.6287 16.2012 10.6873 16.2696L11.5177 17.1C11.5348 17.1167 11.5554 17.1295 11.578 17.1374C11.6006 17.1453 11.6246 17.1482 11.6485 17.1458C11.6719 17.1453 11.6949 17.1391 11.7154 17.1277C11.7359 17.1163 11.7534 17.1001 11.7662 17.0804L13.6296 14.6023C13.7335 14.4655 13.8871 14.375 14.0572 14.3506C14.2273 14.3261 14.4002 14.3695 14.5385 14.4715Z" fill="currentColor"/>
  </svg>
);

const ScheduleIcon = () => (
  <svg width="16" height="18" viewBox="0 0 16 18" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-4 h-4">
    <path fillRule="evenodd" clipRule="evenodd" d="M4.44444 1.8H11.5556V0H13.3333V1.8H14.2222C14.6937 1.8 15.1459 1.98964 15.4793 2.32721C15.8127 2.66477 16 3.12261 16 3.6V16.2C16 16.6774 15.8127 17.1352 15.4793 17.4728C15.1459 17.8104 14.6937 18 14.2222 18H1.77778C1.30628 18 0.854097 17.8104 0.520699 17.4728C0.187301 17.1352 0 16.6774 0 16.2V3.6C0 3.12261 0.187301 2.66477 0.520699 2.32721C0.854097 1.98964 1.30628 1.8 1.77778 1.8H2.66667V0H4.44444V1.8ZM1.77778 5.4V16.2H14.2222V5.4H1.77778ZM3.55556 8.1H5.33333V9.9H3.55556V8.1ZM7.11111 8.1H8.88889V9.9H7.11111V8.1ZM10.6667 8.1H12.4444V9.9H10.6667V8.1ZM10.6667 11.7H12.4444V13.5H10.6667V11.7ZM7.11111 11.7H8.88889V13.5H7.11111V11.7ZM3.55556 11.7H5.33333V13.5H3.55556V11.7Z" fill="currentColor"/>
  </svg>
);

const RejectIcon = () => (
  <svg width="17" height="21" viewBox="0 0 17 21" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-4 h-4">
    <path fillRule="evenodd" clipRule="evenodd" d="M12.5 13.75C10.9812 13.75 9.75 14.9812 9.75 16.5C9.75 17.0004 9.8832 17.4691 10.1167 17.8732L13.8732 14.1167C13.4691 13.8832 13.0004 13.75 12.5 13.75ZM14.9196 15.1916L11.1916 18.9196C11.5806 19.1305 12.0261 19.25 12.5 19.25C14.0188 19.25 15.25 18.0188 15.25 16.5C15.25 16.0261 15.1305 15.5806 14.9196 15.1916ZM8.25 16.5C8.25 14.1528 10.1528 12.25 12.5 12.25C13.689 12.25 14.7652 12.7393 15.5357 13.5256C16.2861 14.2914 16.75 15.3423 16.75 16.5C16.75 18.8472 14.8472 20.75 12.5 20.75C11.3423 20.75 10.2914 20.2861 9.5256 19.5357C8.7393 18.7652 8.25 17.689 8.25 16.5Z" fill="currentColor"/>
    <path d="M12 4C12 6.20914 10.2091 8 8 8C5.79086 8 4 6.20914 4 4C4 1.79086 5.79086 0 8 0C10.2091 0 12 1.79086 12 4Z" fill="currentColor"/>
    <path d="M10.2951 11.1879C8.2137 12.0529 6.75 14.1055 6.75 16.5C6.75 17.8163 7.1943 19.0315 7.9378 20C4.76837e-07 19.9895 0 17.9788 0 15.5C0 13.0147 3.58172 11 8 11C8.7977 11 9.5681 11.0657 10.2951 11.1879Z" fill="currentColor"/>
  </svg>
);


interface Candidate {
  id: number;
  name: string;
  email: string;
  phone?: string;
  role: string;
  experience: string;
  status: 'Shortlist' | 'New' | 'Rejected' | 'Interview';
  appliedDate?: string;
  jobTitle?: string;
  applicationId?: string;
  jobId?: string;
  resumeUrl?: string;
  skills?: string[];
  education?: string;
  location?: string;
}

export default function CandidatesPage() {
  const router = useRouter();
  const [searchTerm, setSearchTerm] = useState('');
  const [experienceFilter, setExperienceFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [loading, setLoading] = useState(true);
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [scheduleModalOpen, setScheduleModalOpen] = useState(false);
  const [selectedCandidate, setSelectedCandidate] = useState<{
    id: number;
    name: string;
    applicationId: string;
    jobId: string;
  } | null>(null);


  // Diagnostic function to test API endpoint
  const testApiEndpoint = async () => {
    console.log('%c=== API DIAGNOSTIC START ===', 'color: blue; font-weight: bold; font-size: 14px');

    const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:8000/api/v1';
    console.log('Base URL:', baseUrl);

    // 1. Test authentication
    console.log('%c1️⃣ Testing /auth/profile...', 'color: orange; font-weight: bold');
    const authResponse = await fetch(`${baseUrl}/auth/profile`, {
      method: 'GET',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
    });
    console.log('   Status:', authResponse.status, authResponse.ok ? '✅' : '❌');

    // 2. Test jobs endpoint
    console.log('%c2️⃣ Testing /jobs/my-jobs...', 'color: orange; font-weight: bold');
    const jobsResponse = await fetch(`${baseUrl}/jobs/my-jobs`, {
      method: 'GET',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
    });
    console.log('   Status:', jobsResponse.status, jobsResponse.ok ? '✅' : '❌');
    const jobsData = await jobsResponse.json();
    console.log('   Jobs found:', jobsData.data?.length || 0);

    if (jobsData.data && jobsData.data.length > 0) {
      const firstJobId = jobsData.data[0].id;
      console.log('   First job ID:', firstJobId);

      // 3. Test applications endpoint
      console.log(`%c3️⃣ Testing /jobs/${firstJobId}/applications...`, 'color: orange; font-weight: bold');
      const appResponse = await fetch(`${baseUrl}/jobs/${firstJobId}/applications`, {
        method: 'GET',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
      });
      console.log('   Status:', appResponse.status, appResponse.ok ? '✅' : '❌');
      console.log('   Status Text:', appResponse.statusText);

      if (!appResponse.ok) {
        const errorData = await appResponse.text();
        console.log('%c❌ ERROR RESPONSE:', 'color: red; font-weight: bold');
        console.log(errorData);
      } else {
        const appData = await appResponse.json();
        console.log('   Applications found:', appData.data?.length || 0);
      }
    }

    console.log('%c=== API DIAGNOSTIC END ===\n', 'color: blue; font-weight: bold; font-size: 14px');
  };

  // Fetch candidates from API
  useEffect(() => {
    const fetchCandidates = async () => {
      try {
        setLoading(true);

        // Clear localStorage on page load to ensure fresh data per recruiter
        localStorage.removeItem("candidates");
        logger.debug('🧹 Cleared localStorage candidates for fresh recruiter data');

        // Run diagnostic first
        console.log('%c🔧 Running API diagnostic...', 'color: purple; font-weight: bold');
        await testApiEndpoint();

        // Get all posted jobs
        console.log('%c🟢 Fetching jobs via jobsApi...', 'color: green; font-weight: bold');
        const jobsResponse = await jobsApi.getMyJobs();
        const jobs = jobsResponse.data || [];
        console.log(`✅ Found ${jobs.length} jobs`);

        if (jobs.length === 0) {
          logger.warn('⚠️ [CANDIDATES] No jobs found, skipping applications fetch');
          setCandidates([]);
          return;
        }

        // Fetch applications for each job
        const allApplications: Candidate[] = [];
        let candidateId = 1;

        for (const job of jobs) {
          try {
            const jobId = job.id || '';
            console.log(`🔵 Fetching applications for job ${jobId} (${job.title})...`);

            const applicationsResponse = await jobsApi.getJobApplications(jobId);

            // Handle different response structures
            // API returns: { job_id, total, applications: [...] }
            let applications: any[] = [];
            const responseData = applicationsResponse.data as any;

            if (Array.isArray(responseData)) {
              // Direct array response
              applications = responseData;
            } else if (responseData?.applications && Array.isArray(responseData.applications)) {
              // { applications: [...] } structure
              applications = responseData.applications;
            } else if (responseData?.data && Array.isArray(responseData.data)) {
              // { data: [...] } structure
              applications = responseData.data;
            }

            console.log(`   ✅ Got ${applications.length} applications`);
            console.log(`   📋 Full Response:`, applicationsResponse);
            console.log(`   📋 Application Details:`, applications);

            console.log(`   📊 Response Structure:`, {
              total: responseData?.total,
              applicationsCount: applications.length,
              keys: responseData ? Object.keys(responseData) : [],
              hasApplicationsField: !!responseData?.applications,
              firstApp: applications.length > 0 ? applications[0] : null,
            });

            applications.forEach((app: any) => {
              allApplications.push({
                id: candidateId++,
                name: app.candidate_name || app.name || `Candidate ${candidateId}`,
                email: app.candidate_email || app.email || '',
                phone: app.phone_number || app.phone || app.candidate_phone || '',
                role: app.position || app.candidate_title || job.title || '',
                experience: app.experience_years || app.candidate_experience || app.experience || 'Not specified',
                status: (app.status === 'interview_scheduled' ? 'Interview' :
                         app.status === 'new' ? 'New' :
                         app.status === 'shortlist' || app.status === 'shortlisted' ? 'Shortlist' :
                         app.status === 'rejected' ? 'Rejected' :
                         app.status || 'New'),
                appliedDate: app.applied_at || app.applied_date || app.application_date || new Date().toISOString(),
                jobTitle: job.title || '',
                applicationId: app.id || app.application_id || '',
                jobId: job.id || app.job_id || '',
                resumeUrl: app.resume_url || app.resume || '',
                skills: app.skills || app.candidate_skills || [],
                education: app.education || app.candidate_education || '',
                location: app.location || app.candidate_location || '',
              });
            });
          } catch (err: any) {
            console.log('%c🔴 [APPLICATION ERROR]', 'color: red; font-weight: bold; font-size: 12px');
            console.log('Job ID:', job.id);
            console.log('Job Title:', job.title);
            console.log('Endpoint attempted: /api/v1/jobs/' + job.id + '/applications');
            console.log('Full error object:', err);
            console.log('Error message:', err?.message);
            console.log('Error code:', err?.code);
            console.log('Error response status:', err?.response?.status);
            console.log('Error response statusText:', err?.response?.statusText);
            console.log('Error response data:', err?.response?.data);
            logger.error('Failed to fetch applications for job:', {
              jobId: job.id,
              jobTitle: job.title,
              status: err?.response?.status,
              statusText: err?.response?.statusText,
              message: err?.message,
              responseData: err?.response?.data,
            });
          }
        }

        // Set candidates from API applications
        if (allApplications.length > 0) {
          setCandidates(allApplications);
        } else {
          // No candidates found
          logger.warn('⚠️ No candidates found from API');
          setCandidates([]);
        }
      } catch (error: any) {
        logger.error('🔴 Error fetching candidates:', {
          message: error?.message,
          status: error?.response?.status,
          statusText: error?.response?.statusText,
          data: error?.response?.data,
        });
        // Show empty state when API fails
        setCandidates([]);
      } finally {
        setLoading(false);
      }
    };

    fetchCandidates();
  }, []);

  const updateStatus = (id: number, status: Candidate['status']) => {
    setCandidates(prev => prev.map(c => c.id === id ? { ...c, status } : c));
  };

  const handleScheduleInterview = (candidateId: number, candidateName: string) => {
    const candidate = candidates.find(c => c.id === candidateId);
    if (!candidate?.applicationId || !candidate?.jobId) {
      alert('Missing required information to schedule interview');
      return;
    }

    // Open the schedule interview modal
    setSelectedCandidate({
      id: candidateId,
      name: candidateName,
      applicationId: candidate.applicationId,
      jobId: candidate.jobId,
    });
    setScheduleModalOpen(true);
  };

  const handleScheduleSuccess = () => {
    // Refresh candidates list or show success message
    setScheduleModalOpen(false);
    setSelectedCandidate(null);
  };

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case 'Shortlist':
        return 'bg-green-100 text-green-700';
      case 'Interview':
        return 'bg-purple-100 text-purple-700';
      case 'New':
        return 'bg-blue-100 text-blue-700';
      case 'Rejected':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const getStatusCount = (status: string) => {
    return candidates.filter(c => c.status === status).length;
  };

  const filteredCandidates = candidates.filter((candidate) => {
    const matchesSearch =
      candidate.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      candidate.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesExperience = !experienceFilter || candidate.experience.includes(experienceFilter);
    const matchesStatus = !statusFilter || candidate.status === statusFilter;

    return matchesSearch && matchesExperience && matchesStatus;
  });

  const sortedCandidates = [...filteredCandidates].sort((a, b) => {
    return new Date(b.appliedDate || '').getTime() - new Date(a.appliedDate || '').getTime();
  });

  const renderActionsByStatus = (status: string, candidateId: number, candidateName: string) => {
    return (
      <>
        {/* View - Available for all statuses */}
        <button
          onClick={() => {
            // Find the candidate to get the applicationId
            const candidate = candidates.find(c => c.id === candidateId);
            if (candidate?.applicationId) {
              router.push(`/recruiter/candidates/${candidate.applicationId}`);
            } else {
              alert('Application ID not found');
            }
          }}
          className="p-2.5 hover:bg-gray-100 rounded-lg transition text-gray-600 cursor-pointer border border-gray-200 hover:border-gray-300"
          title="View Profile"
        >
          <ViewIcon />
        </button>

        {/* New: View, Schedule Interview, Reject */}
        {status === 'New' && (
          <>
            <button
              onClick={() => handleScheduleInterview(candidateId, candidateName)}
              className="p-2.5 hover:bg-blue-50 rounded-lg transition text-blue-600 border border-blue-200 hover:border-blue-300"
              title="Schedule Interview"
            >
              <ScheduleIcon />
            </button>
            <button
              onClick={() => updateStatus(candidateId, 'Rejected')}
              className="p-2.5 hover:bg-red-50 rounded-lg transition text-red-600 border border-red-200 hover:border-red-300"
              title="Reject Candidate"
            >
              <RejectIcon />
            </button>
          </>
        )}

        {/* Shortlist: View, Select (Shortlist), Reject */}
        {status === 'Shortlist' && (
          <>
            <button
              onClick={() => updateStatus(candidateId, 'Shortlist')}
              className="p-2.5 hover:bg-green-50 rounded-lg transition text-green-600 border border-green-200 hover:border-green-300"
              title="Select Candidate"
            >
              <ShortlistIcon />
            </button>
            <button
              onClick={() => updateStatus(candidateId, 'Rejected')}
              className="p-2.5 hover:bg-red-50 rounded-lg transition text-red-600 border border-red-200 hover:border-red-300"
              title="Reject Candidate"
            >
              <RejectIcon />
            </button>
          </>
        )}

        {/* Interview: View, Select (Shortlist), Reject */}
        {status === 'Interview' && (
          <>
            <button
              onClick={() => updateStatus(candidateId, 'Shortlist')}
              className="p-2.5 hover:bg-green-50 rounded-lg transition text-green-600 border border-green-200 hover:border-green-300"
              title="Select Candidate"
            >
              <ShortlistIcon />
            </button>
            <button
              onClick={() => updateStatus(candidateId, 'Rejected')}
              className="p-2.5 hover:bg-red-50 rounded-lg transition text-red-600 border border-red-200 hover:border-red-300"
              title="Reject Candidate"
            >
              <RejectIcon />
            </button>
          </>
        )}

        {/* Rejected: View */}
        {status === 'Rejected' && (
          <div className="text-red-600 px-3 py-1 rounded-lg bg-red-50 text-xs font-medium border border-red-200">
            Rejected
          </div>
        )}
      </>
    );
  };

  if (loading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => router.push('/recruiter/dashboard')}
              className="p-2 hover:bg-gray-100 rounded-lg transition"
            >
              <ChevronLeft className="w-6 h-6 text-gray-600" />
            </button>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Candidates</h1>
              <p className="text-gray-600 text-sm mt-1">Review and manage candidate applications</p>
            </div>
          </div>
        </div>

        {/* Status Stats */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {[
            { label: 'All', count: candidates.length, color: 'bg-gray-100 text-gray-700' },
            { label: 'New', count: getStatusCount('New'), color: 'bg-blue-100 text-blue-700' },
            { label: 'Shortlist', count: getStatusCount('Shortlist'), color: 'bg-green-100 text-green-700' },
          ].map((stat) => (
            <button
              key={stat.label}
              onClick={() => setStatusFilter(stat.label === 'All' ? '' : stat.label)}
              className={`p-4 rounded-lg border-2 transition ${
                (stat.label === 'All' && !statusFilter) || statusFilter === stat.label
                  ? `border-blue-500 ${stat.color}`
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <p className="text-sm font-medium">{stat.label}</p>
              <p className="texti-2xl font-bold mt-1">{stat.count}</p>
            </button>
          ))}
        </div>

        {/* Search and Filters */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
          <div className="mb-6 flex flex-col lg:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search by name, email, or job title..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <select
              value={experienceFilter}
              onChange={(e) => setExperienceFilter(e.target.value)}
              className="px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
            >
              <option value="">Experience</option>
              <option value="0 - 1">0 - 1 years</option>
              <option value="1 - 2">1 - 2 years</option>
              <option value="2 - 4">2 - 4 years</option>
              <option value="3 - 5">3 - 5 years</option>
              <option value="4 - 6">4 - 6 years</option>
              <option value="5 - 7">5 - 7 years</option>
              <option value="6+">6+ years</option>
            </select>
          </div>

          {/* Candidates Table */}
          {sortedCandidates.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b-2 border-gray-200 bg-gray-50">
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Candidate</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Contact</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Position</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Location</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Experience</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Status</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedCandidates.map((candidate) => (
                    <tr key={candidate.id} className="border-b border-gray-200 hover:bg-gray-50 transition">
                      <td className="px-6 py-4">
                        <div>
                          <button
                            onClick={() => {
                              if (candidate.applicationId) {
                                router.push(`/recruiter/candidates/${candidate.applicationId}`);
                              } else {
                                alert('Application ID not found');
                              }
                            }}
                            className="text-sm font-semibold text-blue-600 hover:text-blue-700 hover:underline cursor-pointer"
                          >
                            {candidate.name}
                          </button>
                          <p className="text-xs text-gray-500 mt-1">Applied {new Date(candidate.appliedDate || '').toLocaleDateString()}</p>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="space-y-1">
                          <a href={`mailto:${candidate.email}`} className="flex items-center gap-2 text-sm text-blue-600 hover:text-blue-700">
                            <Mail className="w-4 h-4" />
                            {candidate.email}
                          </a>
                          {candidate.phone && (
                            <a href={`tel:${candidate.phone}`} className="flex items-center gap-2 text-sm text-gray-600 hover:text-gray-700">
                              <Phone className="w-4 h-4" />
                              {candidate.phone}
                            </a>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div>
                          <p className="text-sm font-medium text-gray-900">{candidate.role}</p>
                          <p className="text-xs text-gray-500 mt-1">{candidate.jobTitle}</p>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <p className="text-sm text-gray-600">{candidate.location || 'Not specified'}</p>
                        {candidate.education && <p className="text-xs text-gray-500 mt-1">{candidate.education}</p>}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600">{candidate.experience}</td>
                      <td className="px-6 py-4">
                        <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${getStatusBadgeColor(candidate.status)}`}>
                          {candidate.status}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-1">
                          {renderActionsByStatus(candidate.status, candidate.id, candidate.name)}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-16">
              <Search className="w-12 h-12 text-gray-400 mx-auto mb-3" />
              <p className="text-gray-600 font-medium">No candidates found</p>
              <p className="text-sm text-gray-500 mt-1">Try adjusting your filters or search terms</p>
            </div>
          )}

          {/* Pagination Info */}
          {sortedCandidates.length > 0 && (
            <div className="mt-6 flex items-center justify-between text-sm text-gray-600 border-t border-gray-200 pt-4">
              <p>Showing {sortedCandidates.length} of {candidates.length} candidates</p>
              <div className="flex gap-2">
                <button className="px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition disabled:opacity-50" disabled>
                  Previous
                </button>
                <button className="px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition">
                  Next
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Schedule Interview Modal */}
      {selectedCandidate && (
        <ScheduleInterviewModal
          isOpen={scheduleModalOpen}
          onClose={() => {
            setScheduleModalOpen(false);
            setSelectedCandidate(null);
          }}
          candidateName={selectedCandidate.name}
          applicationId={selectedCandidate.applicationId}
          jobId={selectedCandidate.jobId}
          onSuccess={handleScheduleSuccess}
        />
      )}
    </DashboardLayout>
  );
}
